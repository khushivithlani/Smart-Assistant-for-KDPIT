import re
from distutils.log import debug
from email import message
from os import link
from urllib import response
from flask import Flask, render_template,request,jsonify

from chat import get_response

from sqlconnect import get_answer
from chat import get_link

app = Flask(__name__)

tags={
    "tg1":"tg58|tg59$Domestic Student|International Student",
    "tg58":"tg60|tg61|tg62$Counselling Procedure| Addmission Procedure|Registation fees",
    "tg59":"tg63|tg64|tg62$Counselling Procedure| Addmission Procedure|Registation fees",
    "tg2":"tg4|tg5|tg6|tg7|tg8$Address|Student Strength|Placements|Project & Grant recieved|Contact detail",
    
}

tagsdetail={
    "tg4":"139, CHARUSAT Campus, Highway, Off, Nadiad - Petlad Rd, Changa, Gujarat 388421$",
    
}

@app.get("/")
def index_get():
    return render_template("base.html")

@app.post("/predict")
def perdict():
    text = request.get_json().get("message")
    text.strip()
    if re.match(r"[A-Z0-9]{3}IT\d{3}", text) or re.match(r"[0-9]{2}IT\d{3}", text):
        response =get_answer(text)
        message = {"answer" : "Enter Proper or valid En-Roll number"}
        if response:
            message = {"answer" : response,"link": ""}
        else:
            message = {"answer" : "Enter Proper or valid En-Roll number","link": ""}
        return  jsonify(message)
    response =get_response(text)
    link=get_link()
    message = {"answer" : response,"link": link}
    return  jsonify(message)

@app.post("/tags")
def response_tags():
    text = request.get_json().get("message")
    if text in tags.keys():
        strarray=tags[text].split("$")
        message = {"check" : "tags","tagid":strarray[0],"tag":strarray[1]}
        return  jsonify(message)
    else:
        strarray=tagsdetail[text].split("$")
        message = {"check" : "msg","answer" : strarray[0],"link": strarray[1]}
        return  jsonify(message)
    

if __name__ == "__main__":
    app.run(debug=True)

